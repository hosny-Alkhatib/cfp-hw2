import React from 'react';

const LogPage = ({ setAuth }) => {
  const logIn = () => {
    localStorage.setItem('auth', 'true');
    setAuth(true);
  };
  return (
    <div className='logDiv'>
      <button onClick={logIn} className='btn'>
        <span>log in</span>
      </button>
    </div>
  );
};

export default LogPage;
